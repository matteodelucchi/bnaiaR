void storeNodeResults(SEXP results,network *dag,int storeModes, int nodeid, int vartype);
