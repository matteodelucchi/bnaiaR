test_that("getmarginals() works", {
  skip("getmarginals() tests not yet implemented.")
})
