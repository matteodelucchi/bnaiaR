test_that("calc.node.inla.glm() works", {
  skip("calc.node.inla.glm() test not yet implemented.")
})
